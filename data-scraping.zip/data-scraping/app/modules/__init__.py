"""CrawlRAG modular domains."""
